package Practica_01_UDP_Talk;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controlador implements ActionListener {

		vistaChat vista;
		
		public Controlador(vistaChat vista) {
			this.vista = vista;
			
		}
		
		
		public void actionPerformed(ActionEvent ae) {
			if(ae.getActionCommand().equalsIgnoreCase("enviar")) {
				
			}
		}
		
		
		
		public void enviar() {
			if(vista.)
		}
}
