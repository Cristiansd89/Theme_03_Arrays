

import java.awt.*;
import javax.swing.*;


/*
 * JApplet hereda directamente de applet
 * vamos a crear la interfaz grafica de la calculadora
 */
public class CalculadoraApplet extends JApplet{
/*
 * SOLO TE DEJA GENERAR LOS PROYECTOS EN EL PAQUETE POR DEFECTO	
 */

	//Vamos a crear una clase de tipo InterfazCalculadora 
		private InterfazCalculadora ventanaCalculadora = new InterfazCalculadora();
		
		// El metodo init es imprescindible
		public void init() {
			this.setLayout(new BorderLayout());
			add(ventanaCalculadora, BorderLayout.CENTER);
			
		}
		

}
