

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.*;


public class InterfazCalculadora extends JPanel {
	/*
	 * La la clase InterfazCalculadora va tener otra clase que generara un panel de botones
	 */
	//De claramos el objeto tipo
	private JPanel panelBotones;
	private Controlador controlador;
	private  JLabel pantalla;
	
	//Metodo para añadir botones
	private void addBoton(String texto) {
		
		//Creamos un boton y le pasamos  los datos que queremos que contenga
		JButton boton  = new JButton(texto);
		//añadimos el boton a la clase 
		panelBotones.add(boton);
		boton.addActionListener(controlador);
	}////addBoton
	
	
	
	///Esta Es la interfaz es lo que vamos a ver atraves de la pantalla
	public InterfazCalculadora () {
		//Es el objeto al que los botones van a avisar cuando sean pulsados
		controlador= new Controlador();
		
		//La clase GridLayout se va encargar de organizar los Botones de la calculadora (Rejilla para colocar los elemenos)
		panelBotones = new JPanel (new GridLayout(4,4));
		
		pantalla = new JLabel ("0", JLabel.RIGHT);
		
		// añadimos los botones
		addBoton("7");
		addBoton("8");
		addBoton("9");
		addBoton("+");
		addBoton("4");
		addBoton("5");
		addBoton("6");
		addBoton("-");
		addBoton("1");
		addBoton("2");
		addBoton("3");
		addBoton("*");
		addBoton("0");
		addBoton(".");
		addBoton("/");
		addBoton("=");
		
		
		this.setLayout(new BorderLayout());
		this.add(panelBotones,BorderLayout.CENTER);
		this.add(pantalla,BorderLayout.NORTH);
		
		
	}////////interfazCalculadora
	
	//vamos a crear una Clase anidada y le vamos a decir que implemente la intezfaz action listener
	class Controlador implements ActionListener{
		
			//Variable que va guardar el estado que nos encontramos
			private int estado;
			//Variable para introducir los  simbolos
			private String operador;
			
			private String operando1;
			private String operando2;
			private String ResulCadena;
			private String igual;
			
			static final int ESTADO_INICIAL = 0;
			static final int LEYENDO_OPERANDO_1 = 1;
			static final int OPERADOR_LEIDO = 2;
			static final int LEYENDO_OPERANDO_2= 3;
			
			
			
			
		public Controlador () {
			this.estado = 0;
			this.operador = "";
			this.operando1 = "";
			this.operando2= "";
			//this.ResulCadena ="";
			this.igual ="";
		}/////Metodo Constructor  de la clase Controlador
		
		//Vamos a implementar el metodo
		//Este controlador va capturar la informacion de todos los botones
		@Override
		public void actionPerformed(ActionEvent e) {
			
			//Estemetodo nos avisa  de si se ha pulsado un boton
			JButton boton = (JButton)e.getSource();
			//Estados por los que pasa la calculadora
			switch(this.estado) {
			
			
			/*
			 * Dentro del switch vamos a ir pasando de case en case segun el estado en el que no en
			 * contremos
			 */
			///Si boton pulsado 1,2,3,4,5,6,7,8,9
				case ESTADO_INICIAL :
					
					
					//Primera condicion del if  comprueba si dentro de la cadena esta la variable introducida
					
					if("123456789".contains(boton.getText())) {
						//Introducimos el texto dentro del operador 1
						this.operando1 = boton.getText();
						this.estado = LEYENDO_OPERANDO_1;
						// y mostramos  el el dato untroducido por pantalla
						pantalla.setText(this.operando1);
					
					}
					break;
					
					
					//una  vez leido el primer operador  se guarda en la variable 
					//
				case LEYENDO_OPERANDO_1 :
					if("0123456789".contains(boton.getText())) {
						this.operando1 += boton.getText();
						this.estado = LEYENDO_OPERANDO_1;
						pantalla.setText(this.operando1);
						
						
						//Si la condicion es un (+-*/) pasemos al estado OPERADOR_LEIDO
					}else if ("+-*/".contains(boton.getText())){
						this.operador=boton.getText();
						this.estado = OPERADOR_LEIDO;
						pantalla.setText(this.operador);
					}
					
					break;	
					
					///Operador leido sera el paso a LEYENDO_OPERANDO_2 en el que introduciremos  el segundoOperador
				case OPERADOR_LEIDO:
					if("+-*/".contains(boton.getText())) {
						this.estado = LEYENDO_OPERANDO_2;
						this.operador=boton.getText();
						pantalla.setText(this.operador);
					}
					
					
				case LEYENDO_OPERANDO_2 :
					if("0123456789".contains(boton.getText())) {
						
						this.operando2 += boton.getText();
						this.estado = LEYENDO_OPERANDO_2;
						pantalla.setText(this.operando2);
						
						
						
					}else if ("=".contains(boton.getText())){
						
						///Este estado  vamos a utilizarlo para los resultados
						//this.estado = OPERADOR_LEIDO;
						int numOpe1 = Integer.parseInt(this.operando1);
						int numOpe2 = Integer.parseInt(this.operando2);
						
						///Este es el metodo que CalcularelResultado
						int Resultado = calcularResultado(this.operador, numOpe1, numOpe2);
						
						
						//Metodo para convertir un numero entero en una cadena
						String ResulCadena= String.valueOf(Resultado);
						
						pantalla.setText(ResulCadena);
						///Volvemos a reiniciar las variables
						//para poder seguir introduciendo datos
						this.operador = "";
						this.operando1 = "";
						this.operando2= "";
						this.estado= ESTADO_INICIAL;
						
						
						
					}
					break;
					
				
				}///Switch
			System.out.println("Boton pulsado : " + boton.getText());
			}///Metodo Actionperformed
		
		
			
			public  int calcularResultado(String operador, int numOpe1, int numOpe2) {
				int resultado = 0;
				
				switch(operador) {
					case "+" :
							
						resultado = numOpe1 + numOpe2;
						break;
						
						
					case"-":
						 resultado = numOpe1 - numOpe2;
						 break;
						
						
						
						
					case"*":
						 resultado = numOpe1 * numOpe2;
						 break;
						
						
					case"/":
						
						resultado = numOpe1 / numOpe2;
						break;
				}
				return resultado;
				
				
			}///Metodo Calcular Resultado
		
	
	}///Clase controlador
}		
	