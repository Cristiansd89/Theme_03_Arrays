package api_rest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import api_rest.repository.ComentariosRepository;
import api_rest.model.*;

@RestController
@RequestMapping("/api/v0")
public class ComentariosController {
	
	/*
	 * Revisar esta tabla con Ramon para ver como insertar y ver la manera 
	 * de que no liste todo el Json entero
	 */
	@Autowired
	private ComentariosRepository repositorio;
	
	@GetMapping("/comentarios")
	public List<ComentariosModel> listaComentarios(){
		return repositorio.findAll();
	}
	/*
	@GetMapping("/comentarios/{usuario}")
	public Optional<ComentariosModel> listaComentariosUsuarios(@PathVariable("idComentario")UsuariosModel usuario){
		return repositorio.findById(usuario.getIdUsuario());
	}
	*/
	
	@GetMapping("/comentarios/{idComentario}")
	public Optional<ComentariosModel> comentario(@PathVariable("idComentario")Integer idComentario){
		return repositorio.findById(idComentario);
	}
	
	@PutMapping("/anadir_comentario")
	public void guardar(@RequestBody ComentariosModel comentario ) {
		repositorio.save(comentario);	
	}
	
	@PutMapping("/modificar_comentario")
	public void actualizar(@RequestBody ComentariosModel comentario ) {
		repositorio.save(comentario);	
	}
	
	@DeleteMapping("/eliminar_comentario/{idComentario}")
	public void eliminar(@PathVariable("idComentario") Integer id) {
		repositorio.deleteById(id);
		
	}

}
