package Practica_12_BuscarPalabra;

public class ClienteBuscador {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
