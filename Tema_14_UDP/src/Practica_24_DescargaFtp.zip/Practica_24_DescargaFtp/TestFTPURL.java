package Practica_24_DescargaFtp;

public class TestFTPURL {

	public static void main(String[] args) {
		
		FtpUrlDownload ftp = new FtpUrlDownload();
		ftp.start();
		

	}

}
